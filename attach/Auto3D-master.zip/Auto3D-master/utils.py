#!/usr/bin/env python
# -*- coding: utf-8 -*-

import glob
import os

# note first to add your meshlabserver path into PATH and navigate to the correct directory
# if there are any problems with the textures
# first check with the saving options (-m ...)
# and then check your file format
# make sure you use MeshLab v1.3.4 BETA

"""
A simplified OBJ file loader. The function parses the .obj file and reads in 
necessary information of the model geometry.

Arguments:
    type filename: string
    param filename: the filename of the OBJ file to be loaded

Returns:
    type verts: list
    param verts: vertex coordinates of the model
"""

def loadOBJ(filename):  
    
    numVerts = 0  
    verts = []  
    norms = []  
    vertsOut = []  
    normsOut = []  
    
    with open(filename, "r") as f:
        for line in f:  
            l = line.strip()
            if l == "":
                continue
            vals = l.split()  
            if vals[0] == "v":  
                v = map(float, vals[1:4])  
                verts.append(v)  
            if vals[0] == "vn":  
                n = map(float, vals[1:4])  
                norms.append(n)  
            if vals[0] == "f":  
                for f in vals[1:]:  
                    w = f.split("/")  
                    # OBJ Files are 1-indexed so we must subtract 1 below  
                    vertsOut.append(list(verts[int(w[0])-1]))  
                    normsOut.append(list(norms[int(w[2])-1]))  
                    numVerts += 1  
    
    return verts  


"""
Derive the bounding box from the vertex information in the OBJ model. 

Arguments:
    type verts: list
    param verts: a list of the vertices returned by loadOBJ

Returns:
    type bbox: tuple
    param bbox: the 3D bounding box of a model, specified by the maximum and minimum 
        coordinates in x, y, z respectively
"""

def verts_to_bbox(verts):
    
    xs = []
    ys = []
    zs = []
    
    for v in verts:
        xs.append(v[0])
        ys.append(v[1])
        zs.append(v[2])
    
    bbox = (min(xs), max(xs), min(ys), max(ys), min(zs), max(zs))

    return bbox


"""
Compute the center of a bounding box.

Arguments:
    type bbox: tuple
    param bbox: the 3D bounding box of a model

Returns:
    type center: tuple
    param center: the center of a bounding box, in the order of x, y, z
"""

def bbox_to_center(bbox):
   
    min_x, max_x, min_y, max_y, min_z, max_z = bbox
    center_x = (min_x + max_x) / 2
    center_y = (min_y + max_y) / 2
    center_z = (min_z + max_z) / 2
    
    center = (center_x, center_y, center_z)

    return center


"""
Read in an OBJ file and find the coordinates of its bounding box center.

Arguments:
    type filename: string
    param filename: the filename of the OBJ file

Returns:
    type center: tuple
    param center: the center of the OBJ file
"""

def obj_center(filename):
    
    ext = filename.split(".")[-1].lower()
    assert ext == "obj"
    verts = loadOBJ(filename)
    bbox = verts_to_bbox(verts)
    center = bbox_to_center(bbox)

    return center


"""
Read the transformation from a file.

Arguments:
    type filename: string
    param filename: the filename of the transformation file
        the file should be formatted as
        '
        rotate
        x y z
        scale
        x y z
        translate
        x y z
        '

Returns:
    type rot_x: float
    param rot_x: rotation on the x axis
    type rot_y: float
    param rot_y: rotation on the y axis
    type rot_z: float
    param rot_z: rotation on the z axis
    type scl_x: float
    param scl_x: scaling on the x axis
    type scl_y: float
    param scl_y: scaling on the y axis
    type scl_z: float
    param scl_z: scaling on the z axis
    type tlt_x: float
    param tlt_x: translation on the x axis
    type tlt_y: float
    param tlt_y: translation on the y axis
    type tlt_z: float
    param tlt_z: translation on the z axis
"""

def read_transform(filename):

    rot_x = 0.0
    rot_y = 0.0
    rot_z = 0.0
    scl_x = 0.0
    scl_y = 0.0
    scl_z = 0.0
    tlt_x = 0.0
    tlt_y = 0.0
    tlt_z = 0.0

    with open(filename, "r") as f:
        line = f.readline()
        assert line.strip().split()[0].lower() == "rotate"
        line = f.readline()
        parts = line.strip().split()
        assert len(parts) == 3
        rot_x, rot_y, rot_z = map(float, parts)

        line = f.readline()
        assert line.strip().split()[0].lower() == "scale"
        line = f.readline()
        parts = line.strip().split()
        assert len(parts) == 3
        scl_x, scl_y, scl_z = map(float, parts)

        line = f.readline()
        assert line.strip().split()[0].lower() == "translate"
        line = f.readline()
        parts = line.strip().split()
        assert len(parts) == 3
        tlt_x, tlt_y, tlt_z = map(float, parts)

    return rot_x, rot_y, rot_z, scl_x, scl_y, scl_z, tlt_x, tlt_y, tlt_z


"""
Fill the transformation script parameters provided and save it to the disk.

Arguments:
    type template: string
    param template: filename of the template
    type model: string
    param model: model name
    type trans: tuple
    param trans: the transformation parameters returned by read_transform
"""

def fill_template(template, model, trans):

    with open(model + "_script.mlx", "w") as op:
        with open(template, "r") as ip:
            content = ip.read()
            content = content.format(*trans)
        op.write(content)

    return


"""
Apply the transformation in the script to the OBJ model.

Arguments:
    type model: string
    param model: model name
"""

def transform(model):

    command = ("meshlabserver -i " + model + ".obj" + " -o " + model + "_ml.obj" +
              " -m vc vn fc wt -s " + model + "_script.mlx")
    os.system(command)

    return 


"""
Rename the texture files for easy import of other 3D modelling softwares.

Arguments:
    type model: string
    param model: model name

Returns:
    type name_dict: dict
    param name_dict: a dictionary that maps the old filename to the new one
"""

def rename(model):

    name_dict = {}
    # should contain a texture directory of the same name
    if os.path.isdir(model):
        # typically texture files stored in "$model\"" 
        filenames = glob.glob(model + "\\*.*")
        for idx, filename in enumerate(filenames):
            parts = filename.split("\\")
            path = "\\".join(parts[:-1])
            old = parts[-1]
            ext = old.split(".")[-1]
            new = model + "_" + "%03d" % idx + "." + ext
            new_name = path + "\\" + new
            name_dict[old] = new
            os.rename(filename, new_name)

    return name_dict


"""
Clean the mtl file after renaming -- update the texture paths in the mtl file.

Arguments:
    type model: string
    param model: model name
    type name_dict: dictionary
    param name_dict: the dictionary that maps the old name to the new one
"""

def clean(model, name_dict):

    # the typical naming convention of the MeshLab-transformmed OBJ files
    if os.path.exists(model + "_ml.obj.mtl") and name_dict != {}:
        with open(model + "_ml.obj.mtl") as f:
            content = f.read()

        # rewrite the mtl file
        with open(model + "_ml.obj.mtl", "w") as f:
            for old_name, new_name in name_dict.iteritems():
                new_content = content.replace(old_name, new_name)
            f.write(new_content)

    return


"""
Convert the model to OBJ format.

Arguments:
    type model: string
    param model: model name
    type ext: string
    param ext: the extention of a file
"""

def convert(model, ext):

    if ext != "obj":
        command = ("meshlabserver -i " + model + "." + ext + " -o " + model + ".obj" +
                  " -m vc vn")
        os.system(command)

    return 


"""
The function gathers all components and finishes the entire convertion-transformation-cleaning
pipeline.

Arguments:
    type filename: string
    param filename: model file name
    type template: string
    param template: template filename
    type transfile: string
    param transfile: file that contains the transformation parameters
"""

def main(filename, template, transfile):

    model, ext = filename.split(".")
    convert(model, ext)
    trans = read_transform(transfile)
    fill_template(template, model, trans)
    transform(model)
    name_dict = rename(model)
    clean(model, name_dict)

    return

if __name__ == "__main__":
    main("FloorLamp.obj", "template.mlx", "transform.txt")
    