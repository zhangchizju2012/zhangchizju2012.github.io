# Auto3D: Automatic 3D Model Conversion and Transformation

# Introduction

The script converts models of any file format into OBJ, aligns the center of the model's bounding box to the origin of the world coordinates, applies the transformation specified in a file and renames the texture files to make it easier for rendering engine.

# Dependency

* Windows (currently working only under Windows)
* MeshLab v1.3.4 BETA

# Usage

To run the script, first add the meshlabserver to your environment path and then navigate to the directory where your models are stored. Assuming the transformation is prepared, you can simply run the script or import it and call function main as follows

```Python
import utils
utils.main("your_model_name", "template.mlx", "your_transformation")
```

An example is already provided in the repo: the \*_ml\*s are the script output.

The script will first convert your model into OBJ, read the transformation specified in the transformation file, fill the template to be fed to the meshlabserver, rename the textures, and update the references to the textures in the OBJ's mtl file.

Note that the transformed file should be stored in the same directory and a model-based script will be generated. The model-based script will also triangulate all the meshes in your model.

# Issues

If your model, after conversion to OBJ, does not have texture files, it's either that the model just doesn't have textures or that texture mapping is incorporated inside the .obj file by vertex coloring. Some software might not support this per-vertex color OBJ format.

So it's strongly encouraged to **use OBJ models** in the beginning so that the pipeline works well.
